drop index if exists {{index .Options "Namespace" }}.refresh_tokens_token_idx;
